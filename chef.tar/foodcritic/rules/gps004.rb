rule 'GPS004', 'Cookbook is missing a standard file' do
  tags %w(correctness gps)
  expected_files = %w(README.md metadata.rb)
  cookbook do |path|
    matches = []
    expected_files.each do |f|
      next if File.exist?("#{path}/#{f}")
      matches << {
        filename: f.to_s,
        matched: 'missing',
        line: 0,
        column: 0
      }
    end
    matches
  end
  $CHILD_STATUS
end
