rule 'GPS015', 'Cookbook contains unnecessary files' do
  tags %w(gps correctness)
  unneccessary_files = %w(CHANGELOG.md, runlist.txt, metadata.json)
  cookbook do |filename|
    matches = []
    unneccessary_files.each do |f|
      file = File.join(filename, f).chomp(',')
      matches << file_match(file) if File.exist?(file)
    end
    matches
  end
end
