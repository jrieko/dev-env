rule 'GPS013', 'Attributes are not documented in the README.md' do
  tags %w(gps readme)
  attribute_array = []
  readme_array = []
  cookbook do |filename|
    readme = File.join(filename, 'README.md')
    attribute = File.join(filename, 'attributes', 'default.rb')
    readme_lines = File.readlines(readme)
    attributes_lines = File.readlines(attribute)
    readme_lines.collect.with_index do |line, _index|
      readme_array << line.split('=')[0] if line =~ /^default/
    end.compact
    attributes_lines.collect.with_index do |line, _index|
      attribute_array << line.split('=')[0] if line =~ /^default/
    end.compact
    [file_match(filename)] unless attribute_array.sort! == readme_array.sort!
  end
end
