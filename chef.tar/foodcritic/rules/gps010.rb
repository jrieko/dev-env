rule 'GPS010', 'The windows_install recipe does not check for platform_family' do
  tags %w( recipe correctness gps )
  recipe do |_ast, filename|
    if filename.split('/')[-2] == 'recipes' &&
       filename.split('/')[-1] == 'windows_install.rb'
      lines = File.readlines(filename)
      platform_check = false
      lines.collect.each_with_index do |line, index|
        next unless line.include? 'node[\'platform_family\']'
        it = 1
        # Check lines within block for fatal error message
        until lines[index + it].nil? ||
              lines[index + it].chomp == 'end'
          if lines[index + it].include?('Chef::Application.fatal!')
            platform_check = true
          end
          it += 1
        end
      end
      [file_match(filename)] unless platform_check
    end
  end
end
