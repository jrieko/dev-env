rule 'GPS008', 'Recipe includes a package or yum_package without notifying the ocx_version_manifest resource' do
  tags %w( notifications gps )
  recipe do |ast|
    find_resources(ast, type: 'yum_package').to_a.concat(find_resources(ast, type: 'package').to_a).select do |resource|
      notified_resources = []
      notifications(resource).collect do |notification|
        notified_resources.push notification[:resource_type]
      end
      !notified_resources.include?(:ocx_version_manifest || notified_resources.empty?)
    end
  end
end
