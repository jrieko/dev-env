rule 'GPS014', 'Template file does not include a comment that the file is managed by chef' do
  tags %w( gps template )
  comments = []
  matches = []
  managed = false
  template do |_ast, filename|
    lines = File.readlines(filename)
    lines.each do |line|
      comments << line if line.include? '#'
    end
    comments.each do |comment|
      managed = true if comment.include?('Chef') && comment.include?('managed')
    end
    unless managed
      matches << {
        filename: filename,
        matched: filename,
        line: 1,
        column: 0
      }
    end
    comments.clear
    managed = false
    matches
  end
end
