rule 'GPS003', 'Use version constraints on dependencies' do
  tags %w(style readme gps)
  metadata do |ast|
    ast.xpath('//command[descendant::ident[@value = "depends"]]').map do |dep|
      unless dep.xpath('args_add_block/descendant::tstring_content').count > 1
        dep
      end
    end.compact
  end
end
