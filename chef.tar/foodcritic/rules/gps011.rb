rule 'GPS011', 'The default recipe does not check for platform_family' do
  tags %w( gps correctness recipe)
  recipe do |_ast, filename|
    if filename.split('/')[-2] == 'recipes' && filename.split('/')[-1] == 'default.rb'
      lines = File.readlines(filename)
      platform_check = false
      lines.collect do |line|
        if line.chomp == 'case node[\'platform_family\']'
          platform_check = true
        elsif line.chomp.include? 'if node[\'platform_family\'] =='
          platform_check = true
        end
      end
      [file_match(filename)] unless platform_check
    end
  end
end
