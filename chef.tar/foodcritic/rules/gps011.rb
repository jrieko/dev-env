rule 'GPS011', 'The default recipe does not check for platform_family' do
  tags %w( gps correctness recipe)
  recipe do |_ast, filename|
    if filename.include?('/recipes/') && File.basename(filename) == 'default.rb'
      platform_check = false
      if File.readlines(filename).any? { |l| l.match(/(case|if) node\['platform_family'\]/) }
        platform_check = true
      end
      [file_match(filename)] unless platform_check
    end
  end
end
