rule 'GPS019', 'Do not use the search resource' do
  tags %w(gps style)
  recipe do |ast|
    resources = find_resources(ast, type: :search).find_all
    resources.map { |cmd| match(cmd) }
  end
end
