rule 'GPS021', 'Recipes are not documented in the README.md' do
  tags %w(readme gps)
  cookbook do |filename|
    readme_array = []
    # recipe_array = []
    readme = File.join(filename, 'README.md')
    recipe = File.join(filename, 'recipes')
    readme_lines = File.readlines(readme)
    recipe_array = Dir.foreach(recipe).select { |x| File.file?("#{recipe}/#{x}") }
    readme_lines.collect.with_index do |line, _index|
      readme_array << line.chomp if line =~ /.rb/
    end.compact
    [file_match(filename)] unless recipe_array.sort! == readme_array.sort!
  end
end
