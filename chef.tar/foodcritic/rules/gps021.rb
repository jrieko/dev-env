rule 'GPS021', 'Recipes are not documented in the README.md' do
  tags %w(readme gps)
  cookbook do |filename|
    readme = File.join(filename, 'README.md')
    recipe = File.join(filename, 'recipes')
    readme_recipes = File.readlines(readme).select { |l| l.match(/.rb/) }.map! { |e| e.gsub(/### /, '').chomp }
    recipe_array = Dir.foreach(recipe).select { |x| File.file?("#{recipe}/#{x}") }
    [file_match(filename)] unless recipe_array.sort! - readme_recipes.sort! == []
  end
end
