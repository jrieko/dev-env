rule 'GPS001', 'Package or yum_package resource does not specify version number' do
  tags %w(resource recipe gps)
  recipe do |ast, _filename|
    pkg_res = find_resources(ast, type: 'package').find_all do |cmd|
      cmd_str = (resource_attribute(cmd, 'version') || resource_name(cmd)).to_s
      cmd_action = (resource_attribute(cmd, 'action') ||
        resource_name(cmd)).to_s
      cmd_str == resource_name(cmd) { |svc| resource_name(cmd) == svc } &&
        cmd_action.include?('install')
    end
    yum_pkg_pres = find_resources(ast, type: 'yum_package').find_all do |cmd|
      cmd_str = (resource_attribute(cmd, 'version') || resource_name(cmd)).to_s
      cmd_action = (resource_attribute(cmd, 'action') ||
        resource_name(cmd)).to_s
      cmd_str == resource_name(cmd) { |svc| resource_name(cmd) == svc } &&
        cmd_action.include?('install')
    end
    pkg_res.concat(yum_pkg_pres).map { |cmd| match(cmd) }
  end
end
