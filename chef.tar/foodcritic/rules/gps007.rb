rule 'GPS007', 'Cookbook must include default recipe file' do
  tags %w(correctness recipe gps)
  cookbook do |filename|
    full_path = File.join(filename, 'recipes', 'default.rb')
    [file_match(full_path)] unless File.exist?(full_path)
  end
end
