rule 'GPS016', 'Metadata does not specify the proper supporting operating systems' do
  tags %w( metadata gps)
  ops_supported = []
  ops_observed = []
  cookbook do |filename|
    metadata_file = File.join(filename, 'metadata.rb')
    recipe_path = File.join(filename, 'recipes')
    lines = File.readlines(metadata_file)
    lines.collect.with_index do |line, _index|
      if line.include? 'supports'
        ops_supported << line.split(' ')[1].chomp.scan(/\w+/)
      end
    end
    files_to_check = ['windows_install.rb', 'linux_install.rb']
    files_to_check.each do |file|
      full_path = File.join(recipe_path, file)
      next unless File.exist?(full_path)
      case file
      when 'windows_install.rb'
        ops_observed << 'windows'
      when 'linux_install.rb'
        ops_observed << 'rhel'
      end
    end
    unless ops_supported.flatten.sort!.eql?(ops_observed.sort! && !ops_supported.empty?)
      [file_match(metadata_file)]
    end
  end
end
