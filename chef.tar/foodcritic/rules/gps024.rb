rule 'GPS024', 'Attributes should not be defined outside of the Attributes directory' do
  tags %w( gps style attributes )
  recipe do |_ast, filename|
    unless File.dirname(filename) =~ /attributes/
      lines = File.readlines(filename)
      matches = []
      lines.collect.with_index do |line, index|
        attribute_types = [
          'default[',
          'force_default[',
          'normal[',
          'override[',
          'force_ovverride[',
          'automatic[',
          'set['
        ]
        attribute_types.each do |attr|
          next unless line.include?(attr || "node.#{attr}")
          matches <<  {
            filename: filename,
            matched: filename,
            line: index + 1,
            column: 0
          }
        end
      end
    end
    matches
  end
end
