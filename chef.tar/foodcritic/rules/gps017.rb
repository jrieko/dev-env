rule 'GPS017', 'Template file does not specify any variables' do
  tags %w( correctness files gps )
  template do |_ast, filename|
    lines = File.readlines(filename)
    variable_check = false
    lines.collect do |line|
      variable_check = true if line =~ '<%(.*)%>'
    end
    [file_match(filename)] unless variable_check
  end
end
