gps005_required_fields = {
  'maintainer' => 'Raytheon'
}

req_fields = StringIO.new

gps005_required_fields.each do |k, v|
  req_fields << " #{k}='#{v}'"
end

rule 'GPS005', "Cookbook metadata must have#{req_fields.string}" do
  tags %w(readme gps)
  metadata do |ast, _filename|
    gps005_required_fields.map do |field, value|
      ast.xpath(%(//command[ident/@value='#{field}']/descendant::tstring_content[@value!='#{value}']))
    end
  end
end
