rule 'gps022', 'First key in the node attribute hash should be the name of the cookbook' do
  tags %w(gps attributes correctness)
  matches = []
  cookbook do |filename|
    cookbook_name = File.basename(filename)
    attribute_file = File.join(filename, 'attributes', 'default.rb')
    attribute_lines = File.readlines(attribute_file)
    attribute_lines.collect.with_index do |line, index|
      if line =~ /^default/
        attribute = line.split('=')[0]
        element = attribute.scan(/\w+/)[1]
        unless element.eql?(cookbook_name)
          matches <<  {
            filename: attribute_file,
            matched: attribute_file,
            line: index + 1,
            column: 0
          }
        end
      end
    end
    matches
  end
end
