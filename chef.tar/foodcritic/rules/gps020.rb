rule 'GPS020', 'All node attributes should be defined in the default hash' do
  tags %w( correctness files gps )
  attributes do |ast|
    ast.xpath(%(//vcall/ident[@value!='default' and @value!='node']))
  end
end
