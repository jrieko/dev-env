rule 'GPS012', 'Required cookbooks are not documented in README.md' do
  tags %w( gps readme )
  cookbook do |filename|
    metadata_array = []
    readme_array = []
    metadata_file = File.join(filename, 'metadata.rb')
    readme_file = File.join(filename, 'README.md')
    lines = File.readlines(metadata_file)
    readme_lines = File.readlines(readme_file)
    lines.collect.with_index do |line, _index|
      if line.include? 'depends'
        metadata_array << line.split(' ')[1].chomp.scan(/\w+/)
      end
    end.compact
    readme_lines.collect.with_index do |line, _index|
      readme_array << line.chomp.scan(/"([^"]*)"/) if line.include? 'depends'
    end.compact
    [file_match(filename)] unless readme_array.flatten.sort! == metadata_array.flatten.sort!
  end
end
