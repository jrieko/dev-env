rule 'GPS006', 'Missing "# Copyright <date>, Raytheon Company" declaration' do
  tags %w(correctness gps)
  cookbook do |path|
    matches = []
    recipes = Dir["#{path}/{#{standard_cookbook_subdirs.join(',')}}/**/*.rb"]
    recipes += Dir["#{path}/*.rb"]
    recipes.collect do |recipe|
      next unless recipe.include? '/recipes/'
      next if File.readlines(recipe).any? { |line| line.match(/^# Copyright \d{4}, Raytheon Company$/) }
      matches << {
        filename: recipe,
        matched: recipe,
        line: 0,
        column: 0
      }
    end
    matches
  end
end
