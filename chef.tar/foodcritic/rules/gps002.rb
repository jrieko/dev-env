@corecommands = ['yum -y', 'yum install', 'yum reinstall', 'yum remove', 'mkdir', 'useradd', 'usermod', 'touch']

rule 'GPS002', 'Execute resource used to run chef-provided command' do
  tags %w(resource recipe gps)
  recipe do |ast|
    find_resources(ast, type: 'execute').find_all do |cmd|
      cmd_str = (resource_attribute(cmd, 'command') || resource_name(cmd)).to_s
      @corecommands.any? { |corecommand| cmd_str.include? corecommand }
    end.map { |c| match(c) }
  end
end
