#!/usr/bin/env bash
# install.sh
# Custom install script for Chef
# John R. Ray <john@johnray.io>
# set -x

## Variables

## Functions
main() {

  if [ `cat /etc/redhat-release | grep "5\." | wc -l` -ne 0 ]; then
    PACKAGE_URL="http://10.1.1.101/chef/chef-11.16.2-1.el5.x86_64.rpm"
  else
    PACKAGE_URL="http://10.1.1.101/chef/chef-11.16.2-1.el6.x86_64.rpm"
  fi

  if [ ! -f /usr/bin/chef-client ]; then
    curl $PACKAGE_URL -o /tmp/chef-client-package.rpm
    rpm -Uvh /tmp/chef-client-package.rpm
  fi

  if [ ! -d /etc/chef ]; then
    mkdir /etc/chef
  fi

  chmod 0700 /etc/chef

}

## Source Check
[[ "${BASH_SOURCE}" == "$0" ]] && main "$@"
