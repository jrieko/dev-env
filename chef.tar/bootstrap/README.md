# Bootstrapping Nodes
In order to properly bootstrap your nodes you will need to clone this repo to your ~/.chef directory.
For older clients you will need to have the org validator in place.
Since we do not have a DNS server you will have to specify the Chef Server URL.

## Chef Server URL
For GPS-OCX the Chef Sever URL is https://10.1.1.100/organizaitons/gps-ocx-ifdc

## Windows
`knife bootstrap windows winrm <IP_or_FQDN -N <node_name> -x <admin_account> -P <admin_password> --bootstrap-template "windows" --server-url <chef_server_url>`

## Linux
`knife bootstrap <IP_or_FQDN> -N <node_name> -x root -P <root_password> --bootstrap-template "rhel" --server-url <chef_server_url>`
