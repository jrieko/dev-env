# vim: ft=chef.ruby:
#
# Copyright 2016, Raytheon Company
# This software was developed pursuant to
# Contract Number FA8807-10-C-0001 with the US Government.
# the US Governments rights in and to this copyrighted
# software are as specified in DFAR 252.227-7014,
# which was made part of the above contract.

# ITAR CONTROLLED TECHNICAL DATA
# This software contains data whose export/transfer/disclosure
# is restricted by U.S. law.  Dissemination to non-U.S. persons
# whether in the United States or abroad requires an export
# license or other authorization.
#
name 'code_generator'
maintainer 'Raytheon'
maintainer_email 'john@johnray.io'
license 'raytheon'
description 'Custom code generator cookbook for use with ChefDK'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version '1.1.0'
