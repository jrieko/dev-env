This directory typically contains Chef cookbooks. This repository was
generated with the '--policy-only' option, which means you have chosen
to use a workflow where each cookbook is treated as an independent
software project. As a result, any cookbooks present in this directory
are independent git projects, and the contents of this directory have
been added to .gitignore.

Love,
Chef
