# Code_Generator Cookbook
This is a modified code generator for use with the chef command.

## Requirements

### Platforms
* Linux
* Windows

### Chef
* Chef 11+
* ChefDK 0.10.0+

### Cookbooks
* None

## Attributes
N/A

## Resources/Providers
N/A

## Libraries
N/A

## Usage
### Generate a new cookbook
`chef generate cookbook -C Raytheon -m <you@address.com> -I raytheon <name>`

### Generate a new attribute file
`chef generate attribute <name>`

### Generate a new cookbook_file
`chef generate file <name>`

### Generate a new recipe
`chef generate recipe <name>`

## Development
* Clone this repository from gitlab.

`$ git clone git@gitlab-server:git@gitlab-server:gps-ocx-ifdc/code_generator.git`

* Create a git branch.

`$ git checkout -b feature_<feature_name>_<user_name>`

* Install dependencies.

`$ bundle install`

## License & Authors
**Author:** John R. Ray <john@johnray.io>

```
Copyright: 2016, Raytheon Company
This software was developed pursuant to
Contract Number FA8807-10-C-0001 with the US Government.
The US Governments rights in and to this copyrighted
software are as specified in DFAR 252.227-7014,
which was made part of the above contract.

ITAR CONTROLLED TECHNICAL DATA
This software contains data whose export/transfer/disclosure
is restricted by U.S. law.  Dissemination to noa-U.S. persons
whether in the United States or abroad requires an export
license or other authorization.
```
